package com.example.annchih;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    List<Cat> catList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*catList.add(new Cat("Барсик", 2021));
        catList.add(new Cat("Мурзик", 2019));
        catList.add(new Cat("Рыжик", 2023));
        catList.add(new Cat("Васька", 2020));

        recyclerView = findViewById(R.id.sitesRecyclerView);
        SitesRecyclerAdapter adapter = new SitesRecyclerAdapter(this, catList);
        recyclerView.setAdapter(adapter);
    } */


    }
}