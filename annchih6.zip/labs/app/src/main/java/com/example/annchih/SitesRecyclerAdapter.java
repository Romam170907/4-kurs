package com.example.annchih;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
public class SitesRecyclerAdapter extends RecyclerView.Adapter<SitesRecyclerAdapter.SitesViewHolder> {
    private LayoutInflater layoutInflater;
    private List<Cat> petEntries;
    private FragmentActivity hostActivity;
    public SitesRecyclerAdapter(FragmentActivity hostActivity, List<Cat> petEntries) {
        this.hostActivity = hostActivity;
        this.petEntries = petEntries;
        this.layoutInflater = LayoutInflater.from(hostActivity);
    }
    public void updateList(List<Cat> updatedEntries) {
        this.petEntries = updatedEntries;
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public SitesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View rowView = layoutInflater.inflate(R.layout.recyclerview_item, parent, false);
        return new SitesViewHolder(rowView);
    }
    @Override
    public void onBindViewHolder(@NonNull SitesViewHolder holder, int position) {
        Cat pet = petEntries.get(position);
        holder.nameDisplayView.setText(pet.getName() + " (" + pet.getAge() + ")");
        holder.itemView.setOnClickListener(v -> {
            NextFragment nextFrag = new NextFragment();
            Bundle bundlePayload = new Bundle();
            bundlePayload.putLong("id", pet.getId());
            nextFrag.setArguments(bundlePayload);
            hostActivity.getSupportFragmentManager().beginTransaction()
                    .replace(R.id.Layout_container, nextFrag, "findThisFragment")
                    .addToBackStack(null)
                    .commit();
        });
    }
    @Override
    public int getItemCount() {
        return petEntries.size();
    }
    public static class SitesViewHolder extends RecyclerView.ViewHolder {
        public TextView nameDisplayView;
        public SitesViewHolder(View view) {
            super(view);
            nameDisplayView = view.findViewById(R.id.siteNameTextView);
        }
    }
}