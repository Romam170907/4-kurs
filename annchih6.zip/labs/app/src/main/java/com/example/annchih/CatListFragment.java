package com.example.annchih;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
public class CatListFragment extends Fragment {
    RecyclerView catalogRecyclerView;
    Button createButton;
    DatabaseAdapter dbWorker;
    SitesRecyclerAdapter catalogAdapter;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cat_list, container, false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        catalogRecyclerView = view.findViewById(R.id.sitesRecyclerView);
        createButton = view.findViewById(R.id.addPetButton);
        catalogAdapter = new SitesRecyclerAdapter(getActivity(), new ArrayList<>());
        catalogRecyclerView.setAdapter(catalogAdapter);
        createButton.setOnClickListener(v -> {
            NextFragment nextFrag = new NextFragment();
            Bundle bundlePayload = new Bundle();
            bundlePayload.putLong("id", 0);
            nextFrag.setArguments(bundlePayload);
            getActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.Layout_container, nextFrag, "findThisFragment")
                    .addToBackStack(null)
                    .commit();
        });
    }
    private void loadCats() {
        dbWorker = new DatabaseAdapter(getActivity()).open();
        List<Cat> fetchedCats = dbWorker.getCats();
        dbWorker.close();
        catalogAdapter.updateList(fetchedCats);
    }
    @Override
    public void onResume() {
        super.onResume();
        loadCats();
    }
}