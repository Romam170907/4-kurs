package com.example.annchih;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class DatabaseAdapter {
    private DatabaseHelper dbHelper;
    private SQLiteDatabase database;

    public DatabaseAdapter(Context context) {
        dbHelper = new DatabaseHelper(context.getApplicationContext());
        }

    public DatabaseAdapter open() {
        database = dbHelper.getWritableDatabase();
        return this;
        }

    public void close() {
        dbHelper.close();
        }

    public List<Cat> getCats() {
        List<Cat> cats = new ArrayList<>();
        Cursor cursor = database.query(DatabaseHelper.TABLE, new String[]{DatabaseHelper.COLUMN_ID, DatabaseHelper.COLUMN_NAME, DatabaseHelper.COLUMN_YEAR},
                null, null, null, null, null);

        while (cursor.moveToNext()) {
            long idVal = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
            String nameVal = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NAME));
            int yearVal = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_YEAR));
            cats.add(new Cat(idVal, nameVal, yearVal));
        }
        cursor.close();
        return cats;
    }

    public long insert(Cat cat) {
        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.COLUMN_NAME, cat.getName());
        cv.put(DatabaseHelper.COLUMN_YEAR, cat.getAge());
        return database.insert(DatabaseHelper.TABLE, null, cv);
        }

    public long update(Cat cat) {
        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.COLUMN_NAME, cat.getName());
        cv.put(DatabaseHelper.COLUMN_YEAR, cat.getAge());
        return database.update(
                DatabaseHelper.TABLE,
                cv,
                DatabaseHelper.COLUMN_ID + " = ?",
                new String[]{String.valueOf(cat.getId())} );
        }
    public long delete(long id) {
        return database.delete(
                DatabaseHelper.TABLE,
                DatabaseHelper.COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)} );
        }
    public Cat getCat(long id) {
        Cursor cursor = database.query(
                DatabaseHelper.TABLE,
                null,
                DatabaseHelper.COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)},
                null, null, null );


    Cat cat = null; if (cursor.moveToFirst()) {
        String nameVal = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NAME));
        int yearVal = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_YEAR));
        cat = new Cat(id, nameVal, yearVal);
    }
    cursor.close();
    return cat;
}

}




