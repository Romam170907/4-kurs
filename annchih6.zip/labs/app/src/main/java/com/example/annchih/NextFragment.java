package com.example.annchih;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
public class NextFragment extends Fragment {
    EditText nameInputField;
    EditText ageInputField;
    Button saveActionButton;
    Button removeActionButton;
    DatabaseAdapter dbService;
    long targetCatId = 0;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        return inflater.inflate(R.layout.fragment_next, container, false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        nameInputField = view.findViewById(R.id.nameField);
        ageInputField = view.findViewById(R.id.ageField);
        saveActionButton = view.findViewById(R.id.saveButton);
        removeActionButton = view.findViewById(R.id.deleteButton);
        Bundle incomingArgs = getArguments();
        if (incomingArgs != null) {
            targetCatId = incomingArgs.getLong("id");
        }
        dbService = new DatabaseAdapter(getActivity());
        if (targetCatId > 0) {
            dbService.open();
            Cat existingPet = dbService.getCat(targetCatId);
            dbService.close();
            if (existingPet != null) {
                nameInputField.setText(existingPet.getName());
                ageInputField.setText(existingPet.getAge() + "");
            }
        } else {
// При добавлении кнопка удаления скрывается
            removeActionButton.setVisibility(View.GONE);
        }
        saveActionButton.setOnClickListener(v -> {
            String nameVal = nameInputField.getText().toString();
            int yearVal = Integer.parseInt(ageInputField.getText().toString());
            dbService.open();
            if (targetCatId > 0) {
                Cat catRecord = new Cat(targetCatId, nameVal, yearVal);
                dbService.update(catRecord);
            } else {
                Cat catRecord = new Cat(nameVal, yearVal);
                dbService.insert(catRecord);
            }
            dbService.close();
            getActivity().getSupportFragmentManager().popBackStack();
        });
        removeActionButton.setOnClickListener(v -> {
            dbService.open();
            dbService.delete(targetCatId);
            dbService.close();
            getActivity().getSupportFragmentManager().popBackStack();
        });
    }
}