package com.example.annchih7;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.NavOptions;
import androidx.navigation.Navigation;


public class HomeFragment extends Fragment {
    Button openProfileButton;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        openProfileButton = view.findViewById(R.id.openProfileActionButton);
        openProfileButton.setOnClickListener(v -> {
            NavController currentNavController = Navigation.findNavController(requireView());
            currentNavController.navigate(
                    R.id.profileFragment,
                    null,
                    new NavOptions.Builder()
                            .setPopUpTo(R.id.homeFragment, true)
                            .build(),
                    null
            );
        });

    }
}