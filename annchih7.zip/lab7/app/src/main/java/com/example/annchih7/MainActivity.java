package com.example.annchih7;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentContainerView;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;
import com.google.android.material.bottomnavigation.BottomNavigationView;
public class MainActivity extends AppCompatActivity {
    private NavController mainNavController;
    protected BottomNavigationView navigationBarView;
    protected FragmentContainerView hostContainerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        navigationBarView = findViewById(R.id.bottomNavigationView);
        hostContainerView = findViewById(R.id.fragmentContainerView);

        NavHostFragment hostNavFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.fragmentContainerView);

        if (hostNavFragment != null) {
            mainNavController = hostNavFragment.getNavController();
            NavigationUI.setupWithNavController(navigationBarView, mainNavController);
        }
    }
}
