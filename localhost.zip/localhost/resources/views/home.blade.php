@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

               <form action="{{ route('order') }}" method = "post" class ="m-3">

                   @csrf
                   <div class="mb-3">
                    <label for="" class="form-label">Название заказа</label>
                    <input required name = "name_order" type = "text" class = "form-control" id = "exampleInputEmail" aria-describedby="emailHelp">
                   </div>
                   <div class="mb-3">
                    <label for="" class="form-label">Цена заказа</label>
                    <input required name = "price_order" type = "text" class = "form-control" id = "exampleInputPassword1" aria-describedby="emailHelp">
                   </div>
                   <div class="mb-3">
                    <label for="" class="form-label">Адрес заказа</label>
                    <input required name = "adress_order" type = "text" class = "form-control" id = "exampleInputPassword1" aria-describedby="emailHelp">
                   </div>
                  <div class="form-text">{{ session('msg') }}</div>
                  <button type = "submit" class = "btn btn-primary">Добавить</button>
               </form>
                <div class="card-body">
                    <div class="row row-cols-1 row-cols-md-3 g-4">
                        @foreach($orders as $order)
                        <div class="col">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class = "card-title">#{{ $order->id }}</h5>
                                    <p class="card-text">{{ $order->name_order }}</p>
                                    <p class="card-text">{{ $order->price_order }}</p>
                                    <p class="card-text">{{ $order->address_order }}</p>
                                    <p class="card-text">{{ $order->created_at}}</p>

                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
