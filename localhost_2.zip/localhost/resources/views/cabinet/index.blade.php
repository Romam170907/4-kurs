@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4>Мои заказы</h4>
                    
                </div>

                <div class="card-body">
                    {{-- Сообщение об успехе --}}
                    @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            {{ session('success') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    @endif

                    {{-- Если заказов нет --}}
                    @if($orders->isEmpty())
                        <div class="text-center py-5">
                            <h5>У вас пока нет заказов</h5>
                            <p class="text-muted">Создайте свой первый заказ!</p>
                        </div>
                    @else
                        {{-- Список заказов в виде карточек --}}
                        <div class="row">
                            @foreach($orders as $order)
                                <div class="col-md-6 col-lg-4 mb-4">
                                    <div class="card h-100 shadow-sm">
                                        <div class="card-body">
                                            <h5 class="card-title">{{ $order->name_order }}</h5>
                                            
                                            <ul class="list-unstyled">
                                                <li><strong>Цена:</strong> {{ number_format($order->price_order, 2) }} ₽</li>
                                                <li><strong>Количество:</strong> {{ $order->count_order }}</li>
                                                <li><strong>Общая сумма:</strong> {{ number_format($order->price_order * $order->count_order, 2) }} ₽</li>
                                                <li><strong>Телефон:</strong> {{ $order->phone_order }}</li>
                                                <li><strong>Адрес:</strong> {{ $order->address_order }}</li>
                                                <li><strong>Дата:</strong> {{ $order->created_at->format('d.m.Y H:i') }}</li>
                                            </ul>
                                        </div>
                                        
                                        <div class="card-footer bg-transparent">
                                            <div class="btn-group w-100" role="group">
                                               
                                                <a href="{{ route('orders.show', $order->id) }}" 
                                                   class="btn btn-outline-primary btn-sm">
                                                     Посмотреть
                                                </a>
                                                
                                               
                                                <a href="{{ route('orders.edit', $order->id) }}" 
                                                   class="btn btn-outline-warning btn-sm">
                                                     Изменить
                                                </a>
                                                
                                               
                                                <form action="{{ route('orders.destroy', $order->id) }}" 
                                                      method="POST" 
                                                      onsubmit="return confirm('Вы уверены, что хотите удалить этот заказ?')">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-outline-danger btn-sm">
                                                         Удалить
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection