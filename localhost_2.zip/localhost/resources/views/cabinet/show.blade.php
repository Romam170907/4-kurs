@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4>Заказ #{{ $order->id }}</h4>
                    <a href="{{ route('cabinet') }}" class="btn btn-secondary btn-sm">← Назад</a>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tr>
                                <th style="width: 30%">Название заказа</th>
                                <td>{{ $order->name_order }}</td>
                            </tr>
                            <tr>
                                <th>Цена</th>
                                <td>{{ number_format($order->price_order, 2) }} ₽</td>
                            </tr>
                            <tr>
                                <th>Количество</th>
                                <td>{{ $order->count_order }}</td>
                            </tr>
                            <tr>
                                <th>Общая стоимость</th>
                                <td><strong>{{ number_format($order->price_order * $order->count_order, 2) }} ₽</strong></td>
                            </tr>
                            <tr>
                                <th>Телефон</th>
                                <td>{{ $order->phone_order }}</td>
                            </tr>
                            <tr>
                                <th>Адрес доставки</th>
                                <td>{{ $order->address_order }}</td>
                            </tr>
                            <tr>
                                <th>Дата создания</th>
                                <td>{{ $order->created_at->format('d.m.Y H:i:s') }}</td>
                            </tr>
                            <tr>
                                <th>Дата обновления</th>
                                <td>{{ $order->updated_at->format('d.m.Y H:i:s') }}</td>
                            </tr>
                        </table>
                    </div>

                    <div class="mt-3 d-flex gap-2">
                        <a href="{{ route('orders.edit', $order->id) }}" class="btn btn-warning">
                             Редактировать
                        </a>
                        <form action="{{ route('orders.destroy', $order->id) }}" method="POST" 
                              onsubmit="return confirm('Удалить заказ?')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger"> Удалить</button>
                        </form>
                        <a href="{{ route('cabinet') }}" class="btn btn-secondary"> Все заказы</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection