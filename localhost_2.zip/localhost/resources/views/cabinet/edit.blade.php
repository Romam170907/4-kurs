@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4>Редактирование заказа #{{ $order->id }}</h4>
                    <a href="{{ route('cabinet') }}" class="btn btn-secondary btn-sm">← Назад</a>
                </div>

                <div class="card-body">
                    {{-- Вывод ошибок валидации --}}
                    @if($errors->any())
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form action="{{ route('orders.update', $order->id) }}" method="POST">
                        @csrf
                        @method('PUT')

                       
                        <div class="mb-3">
                            <label for="name_order" class="form-label">Название заказа</label>
                            <input type="text" 
                                   class="form-control @error('name_order') is-invalid @enderror" 
                                   id="name_order" 
                                   name="name_order" 
                                   value="{{ old('name_order', $order->name_order) }}" 
                                   required>
                            @error('name_order')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                       
                        <div class="mb-3">
                            <label for="price_order" class="form-label">Цена (₽)</label>
                            <input type="number" 
                                   class="form-control @error('price_order') is-invalid @enderror" 
                                   id="price_order" 
                                   name="price_order" 
                                   value="{{ old('price_order', $order->price_order) }}" 
                                   step="0.01" 
                                   min="0" 
                                   required>
                            @error('price_order')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                       
                        <div class="mb-3">
                            <label for="count_order" class="form-label">Количество</label>
                            <input type="number" 
                                   class="form-control @error('count_order') is-invalid @enderror" 
                                   id="count_order" 
                                   name="count_order" 
                                   value="{{ old('count_order', $order->count_order) }}" 
                                   min="1" 
                                   required>
                            @error('count_order')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        
                        <div class="mb-3">
                            <label for="phone_order" class="form-label">Телефон</label>
                            <input type="tel" 
                                   class="form-control @error('phone_order') is-invalid @enderror" 
                                   id="phone_order" 
                                   name="phone_order" 
                                   value="{{ old('phone_order', $order->phone_order) }}" 
                                   placeholder="+7 (XXX) XXX-XX-XX" 
                                   required>
                            @error('phone_order')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        {{-- Адрес --}}
                        <div class="mb-3">
                            <label for="address_order" class="form-label">Адрес доставки</label>
                            <textarea class="form-control @error('address_order') is-invalid @enderror" 
                                      id="address_order" 
                                      name="address_order" 
                                      rows="3" 
                                      required>{{ old('address_order', $order->address_order) }}</textarea>
                            @error('address_order')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        {{-- Кнопки --}}
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-success">
                                 Сохранить изменения
                            </button>
                            <a href="{{ route('cabinet') }}" class="btn btn-secondary">
                                Отмена
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection