@extends('layouts.app')

@section('content')
<div class = "container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Главная страница</div>
                <img src="{{ asset('assets/img/map.jpg') }}" alt="map">
                <p>asjasiogjasoigjasg</p>
                <ul>
                    <li>1</li>
                    <li>2</li>
                    <li>3</li>
                </ul>
            </div>
        </div>
    </div>
</div>

@endsection