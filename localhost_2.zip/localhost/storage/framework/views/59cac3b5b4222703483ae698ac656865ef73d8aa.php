

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4>Мои заказы</h4>
                    
                </div>

                <div class="card-body">
                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    
                    <?php if($orders->isEmpty()): ?>
                        <div class="text-center py-5">
                            <h5>У вас пока нет заказов</h5>
                            <p class="text-muted">Создайте свой первый заказ!</p>
                        </div>
                    <?php else: ?>
                        
                        <div class="row">
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 col-lg-4 mb-4">
                                    <div class="card h-100 shadow-sm">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo e($order->name_order); ?></h5>
                                            
                                            <ul class="list-unstyled">
                                                <li><strong>Цена:</strong> <?php echo e(number_format($order->price_order, 2)); ?> ₽</li>
                                                <li><strong>Количество:</strong> <?php echo e($order->count_order); ?></li>
                                                <li><strong>Общая сумма:</strong> <?php echo e(number_format($order->price_order * $order->count_order, 2)); ?> ₽</li>
                                                <li><strong>Телефон:</strong> <?php echo e($order->phone_order); ?></li>
                                                <li><strong>Адрес:</strong> <?php echo e($order->address_order); ?></li>
                                                <li><strong>Дата:</strong> <?php echo e($order->created_at->format('d.m.Y H:i')); ?></li>
                                            </ul>
                                        </div>
                                        
                                        <div class="card-footer bg-transparent">
                                            <div class="btn-group w-100" role="group">
                                               
                                                <a href="<?php echo e(route('orders.show', $order->id)); ?>" 
                                                   class="btn btn-outline-primary btn-sm">
                                                     Посмотреть
                                                </a>
                                                
                                               
                                                <a href="<?php echo e(route('orders.edit', $order->id)); ?>" 
                                                   class="btn btn-outline-warning btn-sm">
                                                     Изменить
                                                </a>
                                                
                                               
                                                <form action="<?php echo e(route('orders.destroy', $order->id)); ?>" 
                                                      method="POST" 
                                                      onsubmit="return confirm('Вы уверены, что хотите удалить этот заказ?')">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-outline-danger btn-sm">
                                                         Удалить
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\localhost\resources\views/cabinet/index.blade.php ENDPATH**/ ?>