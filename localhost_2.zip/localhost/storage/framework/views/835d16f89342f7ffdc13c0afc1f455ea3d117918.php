

<?php $__env->startSection('content'); ?>
<div class = "container" >
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Главная страница</div>
                <img src="<?php echo e(asset('assets/img/map.jpg')); ?>" alt="map">
                <p>asjasiogjasoigjasg</p>
                <ul>
                    <li>1</li>
                    <li>2</li>
                    <li>3</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\localhost\resources\views/index.blade.php ENDPATH**/ ?>