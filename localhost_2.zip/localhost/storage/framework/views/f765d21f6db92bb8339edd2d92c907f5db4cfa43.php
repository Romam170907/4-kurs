

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4>Заказ #<?php echo e($order->id); ?></h4>
                    <a href="<?php echo e(route('cabinet')); ?>" class="btn btn-secondary btn-sm">← Назад</a>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tr>
                                <th style="width: 30%">Название заказа</th>
                                <td><?php echo e($order->name_order); ?></td>
                            </tr>
                            <tr>
                                <th>Цена</th>
                                <td><?php echo e(number_format($order->price_order, 2)); ?> ₽</td>
                            </tr>
                            <tr>
                                <th>Количество</th>
                                <td><?php echo e($order->count_order); ?></td>
                            </tr>
                            <tr>
                                <th>Общая стоимость</th>
                                <td><strong><?php echo e(number_format($order->price_order * $order->count_order, 2)); ?> ₽</strong></td>
                            </tr>
                            <tr>
                                <th>Телефон</th>
                                <td><?php echo e($order->phone_order); ?></td>
                            </tr>
                            <tr>
                                <th>Адрес доставки</th>
                                <td><?php echo e($order->address_order); ?></td>
                            </tr>
                            <tr>
                                <th>Дата создания</th>
                                <td><?php echo e($order->created_at->format('d.m.Y H:i:s')); ?></td>
                            </tr>
                            <tr>
                                <th>Дата обновления</th>
                                <td><?php echo e($order->updated_at->format('d.m.Y H:i:s')); ?></td>
                            </tr>
                        </table>
                    </div>

                    <div class="mt-3 d-flex gap-2">
                        <a href="<?php echo e(route('orders.edit', $order->id)); ?>" class="btn btn-warning">
                             Редактировать
                        </a>
                        <form action="<?php echo e(route('orders.destroy', $order->id)); ?>" method="POST" 
                              onsubmit="return confirm('Удалить заказ?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger"> Удалить</button>
                        </form>
                        <a href="<?php echo e(route('cabinet')); ?>" class="btn btn-secondary"> Все заказы</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\localhost\resources\views/cabinet/show.blade.php ENDPATH**/ ?>