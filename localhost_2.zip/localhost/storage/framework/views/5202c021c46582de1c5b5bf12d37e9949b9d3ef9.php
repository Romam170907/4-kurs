<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

               <form action="<?php echo e(route('order')); ?>" method = "post" class ="m-3">

                   <?php echo csrf_field(); ?>
                   <div class="mb-3">
                    <label for="" class="form-label">Название заказа</label>
                    <input required name = "name_order" type = "text" class = "form-control" id = "exampleInputEmail" aria-describedby="emailHelp">
                   </div>
                   <div class="mb-3">
                    <label for="" class="form-label">Цена заказа</label>
                    <input required name = "price_order" type = "text" class = "form-control" id = "exampleInputPassword1" aria-describedby="emailHelp">
                   </div>
                   <div class="mb-3">
                    <label for="" class="form-label">Количество заказа</label>
                    <input required name = "count_order" type = "text" class = "form-control" id = "exampleInputPassword1" aria-describedby="emailHelp">
                   </div>
                   <div class="mb-3">
                    <label for="" class="form-label">Телефон</label>
                    <input required name = "phone_order" type = "text" class = "form-control" id = "exampleInputPassword1" aria-describedby="emailHelp">
                   </div>
                   <div class="mb-3">
                    <label for="" class="form-label">Адрес заказа</label>
                    <input required name = "adress_order" type = "text" class = "form-control" id = "exampleInputPassword1" aria-describedby="emailHelp">
                   </div>
                  <div class="form-text"><?php echo e(session('msg')); ?></div>
                  <button type = "submit" class = "btn btn-primary">Добавить</button>
               </form>
                <div class="card-body">
                    <div class="row row-cols-1 row-cols-md-3 g-4">
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class = "card-title">#<?php echo e($order->id); ?></h5>
                                    <p class="card-text"><?php echo e($order->name_order); ?></p>
                                    <p class="card-text"><?php echo e($order->price_order); ?></p>
                                    <p class="card-text"><?php echo e($order->count_order); ?></p>
                                    <p class="card-text"><?php echo e($order->phone_order); ?></p>
                                    <p class="card-text"><?php echo e($order->address_order); ?></p>
                                    <p class="card-text"><?php echo e($order->created_at); ?></p>

                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\localhost\resources\views/home.blade.php ENDPATH**/ ?>