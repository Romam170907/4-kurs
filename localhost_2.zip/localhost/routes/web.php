<?php
use App\Http\Controllers\WebController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\OrderController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', [App\Http\Controllers\WebController::class, 'index'])->name('index');
Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::post('/order', [App\Http\Controllers\WebController::class, 'createOrder'])->name('order');

Route::middleware(['auth'])->group(function () {
    
    Route::get('/orders/{id}', [OrderController::class, 'show'])->name('orders.show');
    
   
    Route::get('/orders/{id}/edit', [OrderController::class, 'edit'])->name('orders.edit');
    
   
    Route::put('/orders/{id}', [OrderController::class, 'update'])->name('orders.update');
    
    
    Route::delete('/orders/{id}', [OrderController::class, 'destroy'])->name('orders.destroy');
});

Route::get('/cabinet', [OrderController::class, 'index'])->name('cabinet');