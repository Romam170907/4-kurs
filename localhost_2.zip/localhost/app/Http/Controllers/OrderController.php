<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\Order;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $orders = Auth::user()->orders()->orderBy('created_at', 'desc')->get();
        
        return view('cabinet.index', compact('orders'));
    }

    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         $order = Order::where('id', $id)
                      ->where('user_id', Auth::id())
                      ->firstOrFail();
        
        return view('cabinet.show', compact('order'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
         $order = Order::where('id', $id)
                      ->where('user_id', Auth::id())
                      ->firstOrFail();
        
        return view('cabinet.edit', compact('order'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $order = Order::where('id', $id)
                      ->where('user_id', Auth::id())
                      ->firstOrFail();
         $order->update($validated);

        return redirect()->route('cabinet')
                         ->with('success', 'Заказ успешно обновлён!');
        
        $validated = $request->validate([
            'name_order' => 'required|string|max:255',
            'price_order' => 'required|numeric|min:0',
            'count_order' => 'required|integer|min:1',
            'phone_order' => 'required|string|max:20',
            'address_order' => 'required|string|max:255',
        ]);
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $order = Order::where('id', $id)
                      ->where('user_id', Auth::id())
                      ->firstOrFail();

        $order->delete();

        return redirect()->route('cabinet')
                         ->with('success', 'Заказ успешно удалён!');
    }
    
}
