<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class WebController extends Controller
{
    public function index(){
        return view('index');
    }

    public function createOrder(Request $request){
        DB::table('orders')->insert([
            'user_id' => Auth::id(),
            'name_order' => $request->name_order,
            'price_order' => $request->price_order,
            'count_order' => $request->count_order,
            'phone_order' => $request->phone_order,
            'address_order'=>$request->adress_order,
        ]);

        return redirect(route('home'))->with(['msg'=>'заказдобавлен']);
    }
}
