package com.example.annchih;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        textView = findViewById(R.id.textView);
        Bundle arguments = getIntent().getExtras();
        String name = arguments.getString("name");
        int age = arguments.getInt("age");
        textView.setText("Кот " + name + " " + "Год рождения " + age);
    }
}