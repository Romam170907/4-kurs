package com.example.annchih;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SitesRecyclerAdapter extends RecyclerView.Adapter<SitesRecyclerAdapter.SitesViewHolder> {

    private LayoutInflater inflater;
    private List<Cat> catList;
    private Context context;

    public SitesRecyclerAdapter(Context context, List<Cat> catList) {
        this.context = context;
        this.catList = catList;
        this.inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public SitesRecyclerAdapter.SitesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        view = inflater.inflate(R.layout.recyclerview_item, parent, false);
        return new SitesRecyclerAdapter.SitesViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SitesRecyclerAdapter.SitesViewHolder holder, int position) {
        SitesRecyclerAdapter.SitesViewHolder sitesViewHolder = (SitesRecyclerAdapter.SitesViewHolder) holder;
        Cat cat = catList.get(position);
        sitesViewHolder.productNameTextView.setText(cat.getName());

        sitesViewHolder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, MainActivity2.class);
            intent.putExtra("name", cat.getName());
            intent.putExtra("age", cat.getAge());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return catList.size();
    }

    public static class SitesViewHolder extends RecyclerView.ViewHolder {
        public TextView productNameTextView;

        SitesViewHolder(View view) {
            super(view);
            productNameTextView = view.findViewById(R.id.siteNameTextView);
        }
    }
}